"""
Global pytest fixtures
"""
