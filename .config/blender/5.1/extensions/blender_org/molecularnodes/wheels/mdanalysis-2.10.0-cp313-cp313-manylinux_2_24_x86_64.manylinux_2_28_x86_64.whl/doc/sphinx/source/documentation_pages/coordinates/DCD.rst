.. automodule:: MDAnalysis.coordinates.DCD
