.. automodule:: MDAnalysis.analysis.rms

