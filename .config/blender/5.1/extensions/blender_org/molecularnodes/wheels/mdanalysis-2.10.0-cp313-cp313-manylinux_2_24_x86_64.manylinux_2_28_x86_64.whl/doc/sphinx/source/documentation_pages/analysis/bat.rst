.. automodule:: MDAnalysis.analysis.bat
