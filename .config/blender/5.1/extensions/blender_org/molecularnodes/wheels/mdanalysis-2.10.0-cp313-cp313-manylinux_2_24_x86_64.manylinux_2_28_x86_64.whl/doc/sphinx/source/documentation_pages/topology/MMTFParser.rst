.. automodule:: MDAnalysis.topology.MMTFParser
