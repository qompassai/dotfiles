.. automodule:: MDAnalysis.lib.mdamath
