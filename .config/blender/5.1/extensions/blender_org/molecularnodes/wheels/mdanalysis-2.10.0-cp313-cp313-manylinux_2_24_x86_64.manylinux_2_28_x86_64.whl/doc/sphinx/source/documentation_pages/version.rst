.. automodule:: MDAnalysis.version
