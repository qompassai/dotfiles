.. automodule:: MDAnalysis.analysis.dihedrals
