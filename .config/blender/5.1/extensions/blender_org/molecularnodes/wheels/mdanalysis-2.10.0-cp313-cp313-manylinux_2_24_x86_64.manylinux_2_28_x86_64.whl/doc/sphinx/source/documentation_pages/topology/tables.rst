.. automodule:: MDAnalysis.topology.tables
