.. automodule:: MDAnalysis.visualization.streamlines
