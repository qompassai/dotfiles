.. automodule:: MDAnalysis.coordinates.TRC
