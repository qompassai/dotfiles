.. automodule:: MDAnalysis.analysis.psa

