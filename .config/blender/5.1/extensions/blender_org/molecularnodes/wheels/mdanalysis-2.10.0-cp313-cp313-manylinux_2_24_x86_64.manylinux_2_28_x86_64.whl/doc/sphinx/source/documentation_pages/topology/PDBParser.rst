.. automodule:: MDAnalysis.topology.PDBParser

