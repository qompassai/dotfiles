.. automodule:: MDAnalysis.auxiliary.XVG

