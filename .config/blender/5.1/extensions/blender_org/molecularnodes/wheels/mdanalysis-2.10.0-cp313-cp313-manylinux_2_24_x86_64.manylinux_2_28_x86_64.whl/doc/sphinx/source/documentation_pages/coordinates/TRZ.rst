.. automodule:: MDAnalysis.coordinates.TRZ

