.. automodule:: MDAnalysis.auxiliary.base

