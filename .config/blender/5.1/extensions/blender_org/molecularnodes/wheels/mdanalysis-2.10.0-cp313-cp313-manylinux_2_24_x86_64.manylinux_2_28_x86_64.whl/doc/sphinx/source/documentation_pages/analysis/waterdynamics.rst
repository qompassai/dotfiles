.. automodule:: MDAnalysis.analysis.waterdynamics

