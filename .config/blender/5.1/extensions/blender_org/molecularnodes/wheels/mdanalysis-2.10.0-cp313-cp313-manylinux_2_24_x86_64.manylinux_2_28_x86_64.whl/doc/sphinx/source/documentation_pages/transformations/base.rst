.. automodule:: MDAnalysis.transformations.base
