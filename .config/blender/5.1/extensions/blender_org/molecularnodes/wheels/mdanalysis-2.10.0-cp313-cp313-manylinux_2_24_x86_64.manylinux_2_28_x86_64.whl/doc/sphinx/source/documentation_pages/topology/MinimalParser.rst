.. automodule:: MDAnalysis.topology.MinimalParser
