.. automodule:: MDAnalysis.analysis.density

