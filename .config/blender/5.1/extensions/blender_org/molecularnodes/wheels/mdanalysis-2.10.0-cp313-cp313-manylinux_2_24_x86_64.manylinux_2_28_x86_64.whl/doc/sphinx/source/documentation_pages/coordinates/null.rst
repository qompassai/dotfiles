.. automodule:: MDAnalysis.coordinates.null
