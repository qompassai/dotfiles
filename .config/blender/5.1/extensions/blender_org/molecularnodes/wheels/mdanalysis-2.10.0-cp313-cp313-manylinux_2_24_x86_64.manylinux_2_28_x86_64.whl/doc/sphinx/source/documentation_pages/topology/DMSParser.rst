.. automodule:: MDAnalysis.topology.DMSParser
