.. automodule:: MDAnalysis.coordinates.LAMMPS

