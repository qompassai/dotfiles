.. automodule:: MDAnalysis.coordinates.chain
   
