.. automodule:: MDAnalysis.coordinates.GRO

