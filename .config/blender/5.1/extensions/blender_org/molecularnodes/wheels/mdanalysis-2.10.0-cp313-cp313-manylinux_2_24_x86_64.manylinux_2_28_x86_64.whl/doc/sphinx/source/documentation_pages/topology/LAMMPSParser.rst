.. automodule:: MDAnalysis.topology.LAMMPSParser

