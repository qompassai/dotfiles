.. automodule:: MDAnalysis.topology.GMSParser
