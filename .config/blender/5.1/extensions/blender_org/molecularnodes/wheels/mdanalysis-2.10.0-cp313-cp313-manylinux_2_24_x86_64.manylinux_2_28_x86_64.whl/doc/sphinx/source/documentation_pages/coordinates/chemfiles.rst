.. automodule:: MDAnalysis.coordinates.chemfiles
