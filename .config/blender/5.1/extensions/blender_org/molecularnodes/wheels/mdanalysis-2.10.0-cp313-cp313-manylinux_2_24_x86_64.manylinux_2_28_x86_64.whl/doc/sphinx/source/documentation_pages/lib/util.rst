.. automodule:: MDAnalysis.lib.util

