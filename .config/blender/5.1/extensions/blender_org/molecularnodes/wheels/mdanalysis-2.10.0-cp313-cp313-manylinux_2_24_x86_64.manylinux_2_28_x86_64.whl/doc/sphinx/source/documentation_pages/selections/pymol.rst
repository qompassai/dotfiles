.. automodule:: MDAnalysis.selections.pymol

