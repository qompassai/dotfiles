.. automodule:: MDAnalysis.coordinates.TXYZ

