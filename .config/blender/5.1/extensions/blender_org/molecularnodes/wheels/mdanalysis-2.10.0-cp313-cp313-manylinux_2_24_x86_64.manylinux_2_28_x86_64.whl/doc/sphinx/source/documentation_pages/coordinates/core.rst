.. automodule:: MDAnalysis.coordinates.core
   
