.. automodule:: MDAnalysis.coordinates.base
   
