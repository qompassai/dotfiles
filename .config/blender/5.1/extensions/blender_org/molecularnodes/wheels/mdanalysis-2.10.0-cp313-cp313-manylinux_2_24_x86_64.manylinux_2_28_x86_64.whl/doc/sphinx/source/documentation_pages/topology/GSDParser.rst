.. automodule:: MDAnalysis.topology.GSDParser
